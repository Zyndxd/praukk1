<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');

        if ($this->session->userdata('login') != true) {
            redirect('Login');
        }
    }

	public function index()
	{
        $data = [
            'Kendaraan' => $this->db->get('data')->result()   
        ];
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('Data', $data);
		$this->load->view('footer');
	}

	public function add()
	{
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('proses/tambah_data');
		$this->load->view('footer');
	}

	public function save()
	{
		$plat_nomor      = $this->input->post('plat_nomor');
		$jenis_kendaraan = $this->input->post('jenis_kendaraan');
		$pemilik         = $this->input->post('pemilik');

		$data = array(
			'plat_nomor'      => $plat_nomor,
			'jenis_kendaraan' => $jenis_kendaraan,
			'pemilik'         => $pemilik
		);

		$this->db->insert('data', $data);

		$this->session->set_flashdata('success', 'Data berhasil disimpan');

		redirect('Data');
	}

	public function delete($id)
	{
		$this->db->where('id_kendaraan', $id);
		$this->db->delete('data');

		$this->session->set_flashdata('success', 'Data berhasil dihapus');

		redirect('data');
	}

	public function edit($id)
	{
		$data['kendaraan'] = $this->db->get_where('data', ['id_kendaraan' => $id])->row();
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('proses/edit_data', $data);
		$this->load->view('footer');
	}

	public function update()
	{
		$id_kendaraan    = $this->input->post('id_kendaraan');
		$plat_nomor      = $this->input->post('plat_nomor');
		$jenis_kendaraan = $this->input->post('jenis_kendaraan');
		$pemilik         = $this->input->post('pemilik');

		$data = array(
			'plat_nomor'      => $plat_nomor,
			'jenis_kendaraan' => $jenis_kendaraan,
			'pemilik'         => $pemilik
		);

		$this->db->where('id_kendaraan', $id_kendaraan);
		$this->db->update('data', $data);

		$this->session->set_flashdata('success', 'Data berhasil diupdate');

		redirect('data');
	}
}
