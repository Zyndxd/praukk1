<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('User_model');

        if ($this->session->userdata('login') != true) {
            redirect('Login');
        }

        if ($this->session->userdata('role') != 'admin') {
        show_error('Akses ditolak', 403);
    }
    }

	public function index()
	{
        $data = [
            'User' => $this->db->get('user')->result()   
        ];
        
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('user', $data);
		$this->load->view('footer');
	}

    public function add()
    {
        $this->load->view('header');
        $this->load->view('sidebar');
        $this->load->view('proses/tambah_user');
        $this->load->view('footer');
    }

    public function save()
    {
        $nama_lengkap = $this->input->post('nama_lengkap');
        $username     = $this->input->post('username');
        $password     = md5($this->input->post('password'));
        $role         = $this->input->post('role');

        $data = array(
            'nama_lengkap' => $nama_lengkap,
            'username'     => $username,
            'password'     => $password,
            'role'         => $role
        );

        $this->User_model->insert($data);

        $this->session->set_flashdata('success', 'Data berhasil disimpan');

        redirect('user/add');
    }

    public function delete($id)
    {
        $this->User_model->delete($id);
        $this->session->set_flashdata('success', 'Data berhasil dihapus');

        redirect('user');
    }

    public function edit($id)
    {
        $data['user'] = $this->User_model->get_by_id($id);

        $this->load->view('header');
        $this->load->view('sidebar');
        $this->load->view('proses/edit_user', $data);
        $this->load->view('footer');
    }

    public function update($id)
    {
        $nama_lengkap = $this->input->post('nama_lengkap');
        $username     = $this->input->post('username');
        $password     = md5($this->input->post('password'));
        $role         = $this->input->post('role');

        $data = array(
            'nama_lengkap' => $nama_lengkap,
            'username'     => $username,
            'password'     => $password,
            'role'         => $role
        );

        $this->db->where('id_user', $id);
        $this->db->update('user', $data);

        $this->session->set_flashdata('success', 'Data berhasil diupdate');

        redirect('user');
    }


}


