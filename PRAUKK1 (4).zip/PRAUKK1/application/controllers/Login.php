<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library(['form_validation','session']);
        $this->load->database();
        $this->load->helper(['url','form']);
    }

    public function index()
    {
        // jika sudah login, langsung ke dashboard
        if ($this->session->userdata('login') == true) {
            redirect('dashboard');
        }

        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('auth/login');
        } else {
            $this->_login();
        }
    }

    private function _login()
    {
        $username = $this->input->post('username', true);
        $password = md5($this->input->post('password', true));

        $user = $this->db->get_where('user', [
            'username' => $username,
            'password' => $password
        ])->row();

        if ($user) {

            $session = [
                'id_user' => $user->id_user,
                'username' => $user->username,
                'nama_lengkap' => $user->nama_lengkap,
                'role' => $user->role,
                'login' => true
            ];

            $this->session->set_userdata($session);

            redirect('dashboard');

        } else {

            $this->session->set_flashdata('error', 'Username atau Password salah');
            redirect('Login');

        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('login');
    }
}
