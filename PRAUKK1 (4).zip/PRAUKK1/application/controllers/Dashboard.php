<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');

        if ($this->session->userdata('login') != true) {
            redirect('Login');
        }
    }

	public function index()
    {
        $data['Tiket'] = $this->db->get('tiket')->result();

        $data['total_motor'] = $this->db
            ->where('jenis_kendaraan', 'Motor')
            ->where('jam_keluar IS NULL', null, false)
            ->count_all_results('tiket');

        $data['total_mobil'] = $this->db
            ->where('jenis_kendaraan', 'Mobil')
            ->where('jam_keluar IS NULL', null, false)
            ->count_all_results('tiket');

        $data['total_sepeda'] = $this->db
            ->where('jenis_kendaraan', 'Sepeda')
            ->where('jam_keluar IS NULL', null, false)
            ->count_all_results('tiket');

        $data['total_tiket'] = $this->db
            ->where('jam_keluar IS NULL', null, false)
            ->count_all_results('tiket');

        $this->load->view('header');
        $this->load->view('sidebar');
        $this->load->view('dashboard', $data);
        $this->load->view('footer');
    }


   public function save()
    {
        $plat_nomor = strtoupper(str_replace(' ', '', $this->input->post('plat_nomor') ?? ''));
        $jenis_kendaraan = $this->input->post('jenis_kendaraan') ?? '';

        if ($plat_nomor == '') {
            $this->session->set_flashdata('error', 'Plat nomor wajib diisi');
            redirect('Dashboard');
            return;
        }

        $Kendaraan = $this->db->get_where('data', [
            'plat_nomor' => $plat_nomor
        ])->row();

        if ($Kendaraan) {
            $pemilik = $Kendaraan->pemilik;
        } else {
            $pemilik = 'Tamu';
        }

        $data = [
            'plat_nomor' => $plat_nomor,
            'jenis_kendaraan' => $jenis_kendaraan,
            'pemilik' => $pemilik,
            'jam_masuk' => date('Y-m-d H:i:s')
        ];

        $this->db->insert('tiket', $data);

        $this->session->set_flashdata('success', 'Tiket berhasil dibuat');

        redirect('Dashboard');
    }

    public function exit($id)
{
    $data = [
        'jam_keluar' => date('Y-m-d H:i:s')
    ];

    $this->db->where('id_tiket', $id);
    $this->db->update('tiket', $data);

    $this->session->set_flashdata('success', 'Jam keluar berhasil disimpan');

    redirect('Dashboard');
}

}
