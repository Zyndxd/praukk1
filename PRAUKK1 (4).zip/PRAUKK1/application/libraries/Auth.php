<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth {

	private $CI;

	public function __construct()
	{
		$this->CI =& get_instance();
	}

	/**
	 * Check if user is logged in
	 */
	public function is_logged_in()
	{
		return $this->CI->session->userdata('logged_in') === TRUE;
	}

	/**
	 * Get current user ID
	 */
	public function get_user_id()
	{
		return $this->CI->session->userdata('id');
	}

	/**
	 * Get current username
	 */
	public function get_username()
	{
		return $this->CI->session->userdata('username');
	}

	/**
	 * Get current user data
	 */
	public function get_user_data()
	{
		return array(
			'id' => $this->CI->session->userdata('id'),
			'username' => $this->CI->session->userdata('username'),
			'email' => $this->CI->session->userdata('email')
		);
	}

	/**
	 * Redirect if not logged in
	 */
	public function require_login()
	{
		if (!$this->is_logged_in()) {
			$this->CI->session->set_flashdata('error', 'Silakan login terlebih dahulu!');
			redirect('login');
		}
	}

	/**
	 * Hash password
	 */
	public function hash_password($password)
	{
		return password_hash($password, PASSWORD_BCRYPT);
	}

	/**
	 * Verify password
	 */
	public function verify_password($password, $hash)
	{
		return password_verify($password, $hash);
	}
}
