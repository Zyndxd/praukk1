<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Optional) -->
    <section class="content-header">
        <h1>
            Tambah User
        </h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Tambah User</h3>
                    </div>
                    <form method="post" action="<?= site_url('user/update/'.$user->id_user) ?>">
                        <div class="box-body">
                            <div class="form-group">
                                <label>Nama Lengkap</label>
                                <input type="text" name="nama_lengkap" class="form-control" value="<?= $user->nama_lengkap ?>">
                            </div>
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" class="form-control" value="<?= $user->username ?>">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control" value="<?= $user->password ?>">
                            </div>
                            <div class="form-group">
                                <label>Role</label>
                                <select name="role" class="form-control">
                                    <option value="Admin" <?= $user->role == 'Admin' ? 'selected' : '' ?>>Admin</option>
                                    <option value="Pengelola" <?= $user->role == 'Pengelola' ? 'selected' : '' ?>>Pengelola</option>
                                </select>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">
                                Simpan
                            </button>
                            <a href="<?= site_url('User') ?>" class="btn btn-default">
                                <i class="fa fa-arrow-left"></i> Kembali
                            </a>
                        </div>

                    </form>

                </div>

            </div>

        </div>

    </section>

</div>
