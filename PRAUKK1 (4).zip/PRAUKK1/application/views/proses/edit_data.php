<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Optional) -->
    <section class="content-header">
        <h1>
            Edit Data Kendaraan
            <small>Update informasi kendaraan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('data') ?>"><i class="fa fa-car"></i> Kendaraan</a></li>
            <li class="active">Edit</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Form Edit Data Kendaraan</h3>
                    </div>
                    <form method="post" action="<?= site_url('data/update') ?>">
                        <div class="box-body">
                            <input type="hidden" name="id_kendaraan" value="<?= $kendaraan->id_kendaraan ?>" id="plat">
                            <div class="form-group">
                                <label>Plat Nomor</label>
                                <input type="text" name="plat_nomor" class="form-control" value="<?= $kendaraan->plat_nomor ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Jenis Kendaraan</label>
                                <input type="text" name="jenis_kendaraan" class="form-control" value="<?= $kendaraan->jenis_kendaraan ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Pemilik</label>
                                <input type="text" name="pemilik" class="form-control" value="<?= $kendaraan->pemilik ?>" required>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save"></i> Simpan
                            </button>
                            <a href="<?= site_url('Data') ?>" class="btn btn-default">
                                <i class="fa fa-arrow-left"></i> Kembali
                            </a>
                        </div>

                    </form>

                </div>

            </div>

        </div>

    </section>

</div>
