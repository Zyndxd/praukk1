 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Kendaraan
        <small>Siswa dan Guru</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Data Kendaraan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <i class="icon fa fa-check"></i>
            <?= $this->session->flashdata('success'); ?>
        </div>
        <?php endif; ?>


        <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <i class="icon fa fa-ban"></i>
            <?= $this->session->flashdata('error'); ?>
        </div>
        <?php endif; ?>

      <div class="row">
        <div class="col-xs-12">
          <div class="box">
              <a href="<?= site_url('data/add') ?>" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i> Tambah Data</a>
            <div class="box-body">
              <table class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Plat Nomor</th>
                  <th>Jenis Kendaraan</th>
                  <th>Pemilik</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
            <?php 
            $no = 1;
            foreach ($Kendaraan as $k): 
            ?>
                <tr>
                  <td><?= $no++; ?></td>
                  <td><?= $k->plat_nomor; ?></td>
                  <td><?= $k->jenis_kendaraan; ?></td>
                  <td><?= $k->pemilik; ?></td>
                  <td>
                    <a href='<?= site_url("data/edit/".$k->id_kendaraan) ?>' class="btn btn-warning btn-xs"><i class="fa fa-edit"></i> Edit</a>
                    <a href='<?= site_url("data/delete/".$k->id_kendaraan) ?>' class="btn btn-danger btn-xs" onclick="return confirm('Yakin ingin menghapus data ini?')"><i class="fa fa-trash"></i> Delete</a>
                  </td>
                </tr>
            <?php endforeach; ?>
                </tbody>
                <tfoot> 
                <tr>
                  <th>No</th>
                  <th>Plat Nomor</th>
                  <th>Jenis Kendaraan</th>
                  <th>Pemilik</th>
                  <th>Aksi</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>