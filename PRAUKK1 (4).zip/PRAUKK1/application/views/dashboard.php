<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">   
      <!-- Small boxes (Stat box) -->
      <div class="row">
         <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?= isset($total_tiket) ? $total_tiket : 0 ?></h3>

              <p>Tiket Tercetak</p>
            </div>
            <div class="icon">
              <i class="ion ion-card"></i>
            </div>
            <a class="small-box-footer" data-toggle="modal" data-target="#cetatiket">  Cetak Tiket<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?= isset($total_motor) ? $total_motor : 0 ?>/300</h3>
              <p>Motor</p>
            </div>  
            <div class="icon">
              <i class="ion ion-android-bicycle"></i>
            </div>
            <a href="<?= base_url('data') ?>" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?= isset($total_mobil) ? $total_mobil : 0 ?>/20</h3>
              <p>Mobil</p>
            </div>
            <div class="icon">
              <i class="ion ion-model-s"></i>
            </div>
            <a href="<?= base_url('data') ?>" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?= isset($total_sepeda) ? $total_sepeda : 0 ?>/10</h3>
              <p>Sepeda</p>
            </div>
            <div class="icon">
              <i class="ion ion-android-bicycle"></i>
            </div>
            <a href="<?= base_url('data') ?>" class="small-box-footer"><i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <div class="box-tools pull-right">
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Plat Nomor</th>
                  <th>Jenis Kendaraan</th>
                  <th>Pemilik</th>
                  <th>Jam Masuk</th>
                  <th>Jam Keluar</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
            <?php 
            $no = 1;
            foreach ($Tiket as $t): 
            if ($t->jam_keluar == NULL) {
            ?>
                <tr>
                  <td><?= $no++; ?></td>
                  <td><?= $t->plat_nomor; ?></td>
                  <td><?= $t->jenis_kendaraan; ?></td>
                  <td><?= $t->pemilik; ?></td>
                  <td><?= $t->jam_masuk; ?></td>
                  <td><?= $t->jam_keluar; ?></td>
                  <td>
                    <a href="<?= site_url('Dashboard/exit/'.$t->id_tiket) ?>" 
                      class="btn btn-danger btn-xs">
                      <i class="fa fa-sign-out"></i> Keluar
                    </a>
                  </td>
                </tr>
            <?php 
              }
              endforeach; 
            ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>No</th>
                  <th>Plat Nomor</th>
                  <th>Jenis Kendaraan</th>
                  <th>Pemilik</th>
                  <th>Jam Masuk</th>
                  <th>Jam Keluar</th>
                  <th>Aksi</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
        <div class="modal fade" id="cetatiket" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Cetak Tiket</h4>
              </div>
              <div class="modal-body">
                <div class="box box-primary">
                  <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" method="post" action="<?= site_url('Dashboard/save') ?>">
                      <div class="box-body">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Plat Nomor</label>
                          <input type="text" class="form-control" id="plat_nomor" name="plat_nomor" placeholder="Plat Nomor">
                        </div>
                        <div class="form-group">
                          <label for="jenis_kendaraan">Jenis Kendaraan</label>
                          <select name="jenis_kendaraan" id="jenis_kendaraan" class="form-control">
                            <option value="Motor">Motor</option>
                            <option value="Mobil">Mobil</option>
                            <option value="Sepeda">Sepeda</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputPassword1">Waktu Masuk</label>
                          <input type="datetime-local" class="form-control" id="exampleInputPassword1" placeholder="Waktu Masuk">
                        </div>
                      </div>
                  </div>
                </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
                    </form>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->