 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Laporan
        <small>Parkir</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Laporan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Plat Nomor</th>
                  <th>Jenis Kendaraan</th>
                  <th>Pemilik</th>
                  <th>Jam Masuk</th>
                  <th>Jam Keluar</th>
                </tr>
                </thead>
                <tbody>
            <?php 
            $no = 1;
            foreach ($Tiket as $t): 
            ?>
                <tr>
                  <td><?= $no++; ?></td>
                  <td><?= $t->plat_nomor; ?></td>
                  <td><?= $t->jenis_kendaraan; ?></td>
                  <td><?= $t->pemilik; ?></td>
                  <td><?= $t->jam_masuk; ?></td>
                  <td><?= $t->jam_keluar; ?></td>
                </tr>
            <?php endforeach; ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>No</th>
                  <th>Plat Nomor</th>
                  <th>Jenis Kendaraan</th>
                  <th>Pemilik</th>
                  <th>Jam Masuk</th>
                  <th>Jam Keluar</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
    </div>