<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?= base_url('assets/dist/img/user2-160x160.jpg') ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?= $this->session->userdata('username') ?: 'User' ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <?php $segment = $this->uri->segment(1); ?>
            <ul class="sidebar-menu">
                <li class="header">MAIN NAVIGATION</li>

                <li class="<?= ($segment == 'Dashboard') ? 'active' : '' ?>">
                    <a href="<?= site_url('Dashboard') ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                    </a>
                </li>

                <li class="<?= ($segment == 'Data') ? 'active' : '' ?>">
                    <a href="<?= site_url('Data') ?>">
                    <i class="fa fa-car"></i> <span>Kendaraan</span>
                    </a>
                </li>

                <li class="<?= ($segment == 'Laporan') ? 'active' : '' ?>">
                    <a href="<?= site_url('Laporan') ?>">
                    <i class="fa fa-book"></i> <span>Laporan</span>
                    </a>
                </li>

                <?php if ($this->session->userdata('role') == 'admin'): ?>
                <li class="<?= ($segment == 'User') ? 'active' : '' ?>">
                    <a href="<?= site_url('User') ?>">
                    <i class="fa fa-user"></i> <span>User</span>
                    </a>
                </li>
                <?php endif; ?>

                <li class="header">ACCOUNT</li>
                <li>
                    <a href="<?= site_url('Login/logout') ?>">
                    <i class="fa fa-sign-out"></i> <span>Logout</span>
                    </a>
                </li>
            </ul>
    </section>
    <!-- /.sidebar -->
  </aside>